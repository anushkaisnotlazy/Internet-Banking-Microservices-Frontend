const API_BASE_URL = "http://localhost:1234"; 
 
export const USER_API = `${API_BASE_URL}/user`;
export const TRANSACTION_API = `${API_BASE_URL}/transactions`;
export const BANK_API = `${API_BASE_URL}/bank-core`;
 