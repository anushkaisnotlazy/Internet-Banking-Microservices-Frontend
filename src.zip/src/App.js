// import React from "react";
// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import UserLogin from "./anushka-bank-services/User/UserLogin";
// import UserRegistration from "./anushka-bank-services/User/UserRegistration";
// import Error from "./anushka-bank-services/User/Error";
// import { Link } from "react-router-dom";
// import TransactionHistory from "./anushka-bank-services/Bank-Core/TransactionHistory";
// import Dashboard from "./anushka-bank-services/User/Dashboard";
// import TransferMoney from "./anushka-bank-services/Transaction/TransferMoney";
// import CreateAccount from "./anushka-bank-services/Bank-Core/CreateAccount";
// import AccountDetails from "./anushka-bank-services/Bank-Core/AccountDetails";
// import CurrentBalance from "./anushka-bank-services/Bank-Core/CurrentBalance";
// import Withdraw from "./anushka-bank-services/Transaction/Withdraw";
// import Deposit from "./anushka-bank-services/Transaction/Deposit";
// import ReactDOM from 'react-dom';
// import './index.css';
// import reportWebVitals from './reportWebVitals';
// import 'bootstrap/dist/css/bootstrap.min.css';
 
// function App() {
//     return (
//       <div align="center">
//         <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
//           <div className="container-fluid">
//             <ul className="navbar-nav">
//               <li className="nav-item"><Link className="nav-link" to="/home">Home</Link></li>
//               <li className="nav-item"><Link className="nav-link" to="/register">Register</Link></li>
//               <li className="nav-item"><Link className="nav-link" to="/login">Login</Link></li>
//               <li className="nav-item dropdown">
//                 <a className="nav-link dropdown-toggle" href="#" id="accountDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//                   Account
//                 </a>
//                 <ul className="dropdown-menu" aria-labelledby="accountDropdown">
//                   <li><Link className="dropdown-item" to="/account/create">Create New Account</Link></li>
//                   <li><Link className="dropdown-item" to="/account/details">Account Details</Link></li>
//                   <li><Link className="dropdown-item" to="/account/balance">Current Balance</Link></li>
//                 </ul>
//               </li>
//               <li className="nav-item dropdown">
//                 <a className="nav-link dropdown-toggle" href="#" id="transactionDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//                   Transaction
//                 </a>
//                 <ul className="dropdown-menu" aria-labelledby="transactionDropdown">
//                   <li><Link className="dropdown-item" to="/transaction/withdraw">Withdraw Money</Link></li>
//                   <li><Link className="dropdown-item" to="/transaction/deposit">Deposit Money</Link></li>
//                   <li><Link className="dropdown-item" to="/transaction/transfer">Transfer Money</Link></li>
//                 </ul>
//               </li>
//               <li className="nav-item"><Link className="nav-link" to="/logout">Logout</Link></li>
//             </ul>
//           </div>
//         </nav>
//         <Routes>
//           <Route path="/home" Component={Dashboard}></Route>
//           <Route path="/register" Component={UserRegistration}></Route>
//           <Route path="/login" Component={UserLogin}></Route>
//           <Route path="*" Component={Error}></Route>
//           <Route path="/history" Component={TransactionHistory}></Route>
//           <Route path="/account/create" Component={CreateAccount}></Route>
//           <Route path="/account/details" Component={AccountDetails}></Route>
//           <Route path="/account/balance" Component={CurrentBalance}></Route>
//           <Route path="/transaction/withdraw" Component={Withdraw}></Route>
//           <Route path="/transaction/deposit" Component={Deposit}></Route>
//           <Route path="/transaction/transfer" Component={TransferMoney}></Route>
//         </Routes>
//       </div>
//     );
// }
 
// export default App;
import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UserLogin from "./anushka-bank-services/User/UserLogin";
import UserRegistration from "./anushka-bank-services/User/UserRegistration";
import Error from "./anushka-bank-services/User/Error";
import TransactionHistory from "./anushka-bank-services/Bank-Core/TransactionHistory";
import Dashboard from "./anushka-bank-services/User/Dashboard";
import TransferMoney from "./anushka-bank-services/Transaction/TransferMoney";
import CreateAccount from "./anushka-bank-services/Bank-Core/CreateAccount";
import AccountDetails from "./anushka-bank-services/Bank-Core/AccountDetails";
import CurrentBalance from "./anushka-bank-services/Bank-Core/CurrentBalance";
import Withdraw from "./anushka-bank-services/Transaction/Withdraw";
import Deposit from "./anushka-bank-services/Transaction/Deposit";
import ReactDOM from 'react-dom';
import './index.css';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import UserLogout from "./anushka-bank-services/User/UserLogout";

function App() {
    const [accountDropdownOpen, setAccountDropdownOpen] = useState(false);
    const [transactionDropdownOpen, setTransactionDropdownOpen] = useState(false);

    const toggleAccountDropdown = (e) => {
        e.stopPropagation();
        setAccountDropdownOpen(!accountDropdownOpen);
        setTransactionDropdownOpen(false); // Close other dropdown
    };

    const toggleTransactionDropdown = (e) => {
        e.stopPropagation();
        setTransactionDropdownOpen(!transactionDropdownOpen);
        setAccountDropdownOpen(false); // Close other dropdown
    };

    const closeDropdowns = () => {
        setAccountDropdownOpen(false);
        setTransactionDropdownOpen(false);
    };

    return (
      <div align="center" onClick={closeDropdowns}>
        <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
          <div className="container-fluid">
            <ul className="navbar-nav">
              <li className="nav-item"><Link className="nav-link" to="/home">Home</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/register">Register</Link></li>
              <li className="nav-item"><Link className="nav-link" to="/login">Login</Link></li>
            <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" id="accountDropdown" role="button" onClick={toggleAccountDropdown}>
                  Account
                </a>
                <ul className={`dropdown-menu ${accountDropdownOpen ? 'show' : ''}`} aria-labelledby="accountDropdown">
                  <li><Link className="dropdown-item" to="/account/create">Create New Account</Link></li>
                  <li><Link className="dropdown-item" to="/account/details">Account Details</Link></li>
                  <li><Link className="dropdown-item" to="/account/balance">Current Balance</Link></li>
                </ul>
              </li>
              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" id="transactionDropdown" role="button" onClick={toggleTransactionDropdown}>
                  Transaction
                </a>
                <ul className={`dropdown-menu ${transactionDropdownOpen ? 'show' : ''}`} aria-labelledby="transactionDropdown">
                  <li><Link className="dropdown-item" to="/transaction/withdraw">Withdraw Money</Link></li>
                  <li><Link className="dropdown-item" to="/transaction/deposit">Deposit Money</Link></li>
                  <li><Link className="dropdown-item" to="/transaction/transfer">Transfer Money</Link></li>
                </ul>
              </li>
              <li className="nav-item"><Link className="nav-link" to="/logout">Logout</Link></li>
            </ul>
          </div>
        </nav>
        <Routes>
          <Route path="/home" element={<Dashboard />} />
          <Route path="/register" element={<UserRegistration />} />
          <Route path="/login" element={<UserLogin />} />
          <Route path="*" element={<Error />} />
          <Route path="/history" element={<TransactionHistory />} />
          <Route path="/account/create" element={<CreateAccount />} />
          <Route path="/account/details" element={<AccountDetails />} />
          <Route path="/account/balance" element={<CurrentBalance />} />
          <Route path="/transaction/withdraw" element={<Withdraw />} />
          <Route path="/transaction/deposit" element={<Deposit />} />
          <Route path="/transaction/transfer" element={<TransferMoney />} />
          <Route path="/logout" element={<UserLogout />} />

        </Routes>
      </div>
    );
}

export default App;