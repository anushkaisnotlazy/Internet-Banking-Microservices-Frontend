import React, { useState } from 'react';
import axios from 'axios';
import axiosInstance from '../utils/axiosInstance';

const Deposit = () => {
    const [accountNumber, setAccountNumber] = useState('');
    const [amount, setAmount] = useState('');
    const [message, setMessage] = useState('');

    const handleDeposit = async (e) => {
        e.preventDefault();
        try {
            const response = await axiosInstance.post('/transactions/addMoney', {
                accountNumber,
                amount: parseFloat(amount),
            });
            console.log(response.data);
            setMessage(`Deposit successful!!'}`);
    } catch (error) {
        setMessage(`Deposit failed: ${error.response.data.message || 'An error occurred'}`);
    }
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center">Deposit Money</h2>
            <form onSubmit={handleDeposit} className="mt-4">
                <div className="form-group">
                    <label htmlFor="accountNumber">Account Number</label>
                    <input
                        type="text"
                        className="form-control"
                        id="accountNumber"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="amount">Amount</label>
                    <input
                        type="number"
                        className="form-control"
                        id="amount"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary btn-block mt-3">Deposit</button>
            </form>
            {message && <div className="alert alert-info mt-4">{message}</div>}
        </div>
    );
};

export default Deposit;