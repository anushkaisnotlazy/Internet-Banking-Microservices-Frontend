import React, { useState } from 'react';
import { Card, Form, Button, Alert } from 'react-bootstrap';
import axios from 'axios';
import axiosInstance from '../utils/axiosInstance';

const TransferMoney = () => {
    const [senderAccount, setSenderAccount] = useState('');
    const [receiverAccount, setReceiverAccount] = useState('');
    const [amount, setAmount] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleTransfer = async (e) => {
        e.preventDefault();
        try {
            const response = await axiosInstance.post('/transactions/transfer', null, {
                params: {
                    senderAccount,
                    receiverAccount,
                    amount
                }
            });
            setMessage(response.data);
            setError('');
        } catch (err) {
            setError(err.response.data);
            setMessage('');
        }
    };

    return (
        <Card className="mt-5">
            <Card.Header>Transfer Funds</Card.Header>
            <Card.Body>
                <Form onSubmit={handleTransfer}>
                    <Form.Group controlId="formSenderAccount">
                        <Form.Label>Sender Account</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Enter sender account number"
                            value={senderAccount}
                            onChange={(e) => setSenderAccount(e.target.value)}
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formReceiverAccount" className="mt-3">
                        <Form.Label>Receiver Account</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Enter receiver account number"
                            value={receiverAccount}
                            onChange={(e) => setReceiverAccount(e.target.value)}
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formAmount" className="mt-3">
                        <Form.Label>Amount</Form.Label>
                        <Form.Control
                            type="number"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            required
                        />
                    </Form.Group>

                    <Button variant="primary" type="submit" className="mt-3">
                        Transfer
                    </Button>
                </Form>

                {message && <Alert variant="success" className="mt-3">{message}</Alert>}
                {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
            </Card.Body>
        </Card>
    );
};

export default TransferMoney;