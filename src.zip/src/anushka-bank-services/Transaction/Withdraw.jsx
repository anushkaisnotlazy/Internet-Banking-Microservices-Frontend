import React, { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import axiosInstance from '../utils/axiosInstance';

const Withdraw = () => {
    const [accountNumber, setAccountNumber] = useState('');
    const [amount, setAmount] = useState('');
    const [message, setMessage] = useState('');

    const handleWithdraw = async (e) => {
        e.preventDefault();
        try {
            const response = await axiosInstance.post('http://localhost:1234/transactions/withdraw', {
                accountNumber,
                amount: parseFloat(amount)
            });
            setMessage(`Withdrawal successful!!`);
        } catch (error) {
            setMessage(`Error: ${error.response ? error.response.data : 'Server error'}`);
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center">Withdraw Money</h2>
            <form onSubmit={handleWithdraw} className="mt-4">
                <div className="form-group">
                    <label htmlFor="accountNumber">Account Number</label>
                    <input
                        type="text"
                        className="form-control"
                        id="accountNumber"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="amount">Amount</label>
                    <input
                        type="number"
                        className="form-control"
                        id="amount"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary btn-block mt-3">Withdraw</button>
            </form>
            {message && <div className="alert alert-info mt-4">{message}</div>}
        </div>
    );
};

export default Withdraw;