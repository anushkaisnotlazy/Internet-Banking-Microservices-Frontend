import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import axiosInstance from "../utils/axiosInstance";
import "./User.css";

const UserRegistration = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
    roles: "",
  });

  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:1234/auth/new", user);
      console.log('Registeration Successfull!!!!', response.data);
            if(response.data==='This UserName is Already Registered.'){
                alert("User Already Exists.")
            }else{
                alert("Registration Successfull!!!")
                navigate("/")
            }
      navigate("/login");
    } catch (err) {
      setError("Registration failed. Try again.");
    }
  };

  return (
    <div className="container form-container" style={{ color: '#522157' }}>
      <h2 className="text-center">User Registration</h2>
      {error && <p className="alert alert-danger">{error}</p>}
      <form onSubmit={handleSubmit} className="form-box">
        <div className="form-group">
          <label>Name</label>
          <input type="text" className="form-control" name="name" onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" className="form-control" name="email" onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" className="form-control" name="password" onChange={handleChange} required />
        </div>
        <div className="form-group">
          <label>Role</label>
          <select className="form-control" name="roles" onChange={handleChange} required>
            <option value="">Select Role</option>
            <option value="admin">ADMIN</option>
            <option value="user">USER</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary w-100" style={{ backgroundColor: '#522157', borderColor: '#522157' }}>
          Register
        </button>
      </form>
    </div>
  );
};

export default UserRegistration;