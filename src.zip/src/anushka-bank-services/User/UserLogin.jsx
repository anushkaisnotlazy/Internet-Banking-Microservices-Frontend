import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
// import { jwtDecode } from 'jwt-decode';


const UserLogin = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });

  const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData((prevState) => ({
          ...prevState,
          [name]: value
      }));
  };

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
  try {
    const response = await axios.post('http://localhost:1234/auth/authenticate', formData);
    console.log('Login Successful!', response.data);
    // const decodedToken = jwt_decode(response.data);
    // const roles = decodedToken.roles;
    // console.log('Roles:', roles);

    if (response.data === 'Invalid user request !') {
        alert('Invalid user request!');
    } else {
        alert('Login Successful!');
        
        // Assuming response.data contains the token
        const token = response.data.token;
        const roles = response.data.roles;

        console.log("role:", roles);
        localStorage.setItem('token', token);
        localStorage.setItem('userrole', roles);

        fetchUserRole(roles);
    }
} catch (error) {
    console.error('There was an error logging in', error);
    alert('Error logging in');
}
    setFormData({
      username: '',
      password: ''
    });
  };

  const fetchUserRole = async (userId) => {
    try {
      const roleResponse = await axios.get(`http://127.0.0.1:1234/auth/getroles/${userId}`);
      const userRole = roleResponse.data;
      localStorage.setItem('role', userRole);
      console.log('stored', localStorage.getItem('role'));

      if (userRole === 'user') {
        navigate('/user-dashboard');
      } else if (userRole === 'admin') {
        navigate('/admin-dashboard');
      }
    } catch (error) {
      console.error('There was an error fetching the user role', error);
      alert('Error fetching user role');
    }
  };

  return (
    <>
      <h1 className="mt-4 text-center" style={{ color: '#522157' }}>
        <strong>BANK OF ANUSHKA</strong>
      </h1>
      <h2 className="mt-4 text-center" style={{ color: '#522157' }}>
        <strong>We are here for you(r money)!!</strong>
      </h2>
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-10">
            <div className="p-4 shadow-lg" style={{ borderRadius: '10px', backgroundColor: 'lightgray', minHeight: '380px' }}>
              <h2 className="text-center mb-4" style={{ color: '#522157' }}>
                <strong>Login</strong>
              </h2>
              <form onSubmit={handleLogin}>
                <div className="form-group">
                  <input
                    type="text"
                    className="form-control mt-4 mb-4"
                    id="username"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    placeholder="Enter Your Username"
                    style={{ borderColor: '#522157' }}
                  />
                </div>
                <div className="form-group">
                  <input
                    type="password"
                    className="form-control mt-4"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="Enter Your Password"
                    required
                    style={{ borderColor: '#522157' }}
                  />
                </div>
                <button type="submit" className="btn btn-primary btn-block mt-4" style={{ backgroundColor: '#522157', borderColor: '#522157', width: '100%' }}>
                  Login
                </button>
              </form>
              <hr className="my-4" />
              <div className="text-center">
                <p>
                  Don't have an account?{' '}
                  <Link to="/register" style={{ textDecoration: 'none', color: '#522157' }}>
                    <strong>Sign Up</strong>
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserLogin;
// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";
// import "bootstrap/dist/css/bootstrap.min.css";
 
// const UserLogin = () => {
//   const [formData, setFormData] = useState({ username: "", password: "" });
//   const [error, setError] = useState("");
//   const navigate = useNavigate();
 
//   // Handle input changes
//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({ ...formData, [name]: value });
//   };
 
//   // Handle login
//   const handleLogin = async (e) => {
//     e.preventDefault();
//     setError("");
 
//     try {
// const response = await axios.post("http://localhost:1234/auth/authenticate", formData);
      
//       // Check for invalid user
//       if (response.data === "invalid user request !") {
//         alert("Invalid user request!");
//         return;
//       }
 
//       // Store JWT token and userId in local storage
//       localStorage.setItem("token", response.data.token);
//       localStorage.setItem("userid", response.data.userId);
 
//       // Fetch user role after login
//       fetchUserRole(response.data.userId);
//     } catch (error) {
//       console.error("There was an error logging in", error);
//       setError("Invalid username or password");
//     }
//   };
 
//   // Fetch user role after login
//   const fetchUserRole = async (userId) => {
//     try {
// const roleResponse = await axios.get(`http://localhost:1234/auth/getroleofuser/${userId}`, {
//         headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }, // Attach JWT token
//       });
 
//       const userRole = roleResponse.data;
//       localStorage.setItem("role", userRole);
 
//       // Redirect user based on role
//       if (userRole === "user") {
//         navigate("/user-dashboard");
//       } else if (userRole === "admin") {
//         navigate("/admin-dashboard");
//       }
//     } catch (error) {
//       console.error("There was an error fetching the user role", error);
//       alert("Error fetching user role");
//     }
//   };
 
//   return (
//     <div className="container mt-5">
//       <h1 className="text-center" style={{ color: "#522157" }}>
//         <strong>BANK OF ANUSHKA</strong>
//       </h1>
//       <h2 className="text-center" style={{ color: "#522157" }}>
//         <strong>We are here for you(r money) !!</strong>
//       </h2>
 
//       <div className="row justify-content-center">
//         <div className="col-md-6">
//           <div className="p-4 shadow-lg" style={{ borderRadius: "10px", backgroundColor: "lightgray", minHeight: "388px" }}>
//             <h2 className="text-center mb-4" style={{ color: "#522157" }}>
//               <strong>Login</strong>
//             </h2>
 
//             {error && <p className="text-danger text-center">{error}</p>}
 
//             <form onSubmit={handleLogin}>
//               <div className="form-group mb-3">
//                 <label>Username</label>
//                 <input
//                   type="text"
//                   className="form-control"
//                   id="username"
//                   name="username"
//                   value={formData.username}
//                   onChange={handleChange}
//                   placeholder="Enter Your Username"
//                   required
//                 />
//               </div>
 
//               <div className="form-group mb-3">
//                 <label>Password</label>
//                 <input
//                   type="password"
//                   className="form-control"
//                   id="password"
//                   name="password"
//                   value={formData.password}
//                   onChange={handleChange}
//                   placeholder="Enter Your Password"
//                   required
//                 />
//               </div>
 
//               <button type="submit" className="btn btn-primary w-100" style={{ backgroundColor: "#522157", borderColor: "#522157" }}>
//                 Login
//               </button>
//             </form>
 
//             <div className="text-center mt-3">
//               <p>
//                 Don't have an account?{" "}
//                 <Link to="/register" style={{ textDecoration: "none", color: "#522157" }}>
//                   <strong>Sign Up</strong>
//                 </Link>
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };
 
// export default UserLogin;