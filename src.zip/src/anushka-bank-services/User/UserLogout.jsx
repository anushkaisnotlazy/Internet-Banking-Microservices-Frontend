import React from 'react';
import { Card, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const UserLogout = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        // Clear user session or token here
        localStorage.removeItem('userToken');
        // Redirect to login page
        navigate('/login');
    };

    return (
        <Card style={{ width: '18rem', margin: 'auto', marginTop: '50px' }}>
            <Card.Body>
                <Card.Title>Logout</Card.Title>
                <Card.Text>
                    Are you sure you want to log out?
                </Card.Text>
                <Button variant="primary" onClick={handleLogout}>Logout</Button>
            </Card.Body>
        </Card>
    );
};

export default UserLogout;