import React, { useState } from 'react';
import axios from 'axios';
import { Button, Form, Alert } from 'react-bootstrap';

const DeleteUser = () => {
    const [userId, setUserId] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleDelete = async (e) => {
        e.preventDefault();
        try {
            await axios.delete(`http://localhost:8083/users/delete/${userId}`);
            setMessage('User deleted successfully');
            setError('');
        } catch (err) {
            setError('Error deleting user');
            setMessage('');
        }
    };

    return (
        <div className="container mt-5">
            <h2>Delete User Account</h2>
            <Form onSubmit={handleDelete}>
                <Form.Group controlId="formUserId">
                    <Form.Label>User ID</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter user ID"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        required
                    />
                </Form.Group>
                <Button variant="danger" type="submit" className="mt-3">
                    Delete User
                </Button>
            </Form>
            {message && <Alert variant="success" className="mt-3">{message}</Alert>}
            {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
        </div>
    );
};

export default DeleteUser;