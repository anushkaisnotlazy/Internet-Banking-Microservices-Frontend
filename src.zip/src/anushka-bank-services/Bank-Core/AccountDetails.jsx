import React, { useEffect, useState } from 'react';
import axiosInstance from '../utils/axiosInstance';

const AccountDetails = ({ accountNumber }) => {
    const [accountDetails, setAccountDetails] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    //console.log(accountNumber);
    
    useEffect(() => {
        const fetchAccountDetails = async () => {
            try {
                const response = await axiosInstance.get(`/accounts/${accountNumber}`);
                setAccountDetails(response.data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchAccountDetails();
    }, [accountNumber]);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    if (!accountDetails) {
        return <div>No account details found</div>;
    }

    return (
        <div>
            <h2>Account Details</h2>
            <p><strong>Account Number:</strong> {accountDetails.accountNumber}</p>
            <p><strong>Account Holder Name:</strong> {accountDetails.accountHolderName}</p>
        </div>
    );
};

export default AccountDetails;