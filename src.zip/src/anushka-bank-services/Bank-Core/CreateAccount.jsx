import React, { useState } from 'react';
import { Card, Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../utils/axiosInstance';

const CreateAccount = () => {
    const [user, setUser] = useState({
        name: '',
        mobileNumber: '',
        email: '',
        age: ''
    });
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axiosInstance.post('/users/register', {
                name: user.name,
                mobileNumber: user.mobileNumber,
                email: user.email,
                age: user.age
            }, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if (response.status === 200) {
                navigate('/account/details');
            } else {
                setError('Registration failed. Try again.');
            }
        } catch (err) {
            setError(err.response ? err.response.data.message : 'Registration failed. Try again.');
        }
    };

    return (
        <Card style={{ width: '30rem', margin: 'auto', marginTop: '2rem' }}>
            <Card.Body>
                <Card.Title>Create New Account</Card.Title>
                {error && <p className="alert alert-danger">{error}</p>}
                <Form onSubmit={handleSubmit}>
                    <Form.Group controlId="formName">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={user.name}
                            onChange={handleChange}
                            placeholder="Enter name"
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formMobileNumber">
                        <Form.Label>Mobile Number</Form.Label>
                        <Form.Control
                            type="text"
                            name="mobileNumber"
                            value={user.mobileNumber}
                            onChange={handleChange}
                            placeholder="Enter mobile number"
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            type="email"
                            name="email"
                            value={user.email}
                            onChange={handleChange}
                            placeholder="Enter email"
                            required
                        />
                    </Form.Group>

                    <Form.Group controlId="formAge">
                        <Form.Label>Age</Form.Label>
                        <Form.Control
                            type="number"
                            name="age"
                            value={user.age}
                            onChange={handleChange}
                            placeholder="Enter age"
                            required
                        />
                    </Form.Group>

                    <Button variant="primary" type="submit" style={{ marginTop: '1rem' }} color='#522157'>
                        Create Account
                    </Button>
                </Form>
            </Card.Body>
        </Card>
    );
};

export default CreateAccount;
