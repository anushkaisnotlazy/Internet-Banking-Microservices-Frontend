import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const CurrentBalance = () => {
    const [balance, setBalance] = useState(null);
    const [accountDetails, setAccountDetails] = useState({});

    useEffect(() => {
        const fetchBalance = async () => {
            try {
                const response = await axios.get('http://localhost:1234/accounts/balance/');
                setBalance(response.data.balance);
            } catch (error) {
                console.error('Error fetching balance:', error);
            }
        };

        const fetchAccountDetails = async () => {
            try {
                const response = await axios.get('http://localhost:1234/accounts/balance/');
                setAccountDetails(response.data);
            } catch (error) {
                console.error('Error fetching account details:', error);
            }
        };

        fetchBalance();
        fetchAccountDetails();
    }, []);

    return (
        <div className="container mt-5">
            <div className="card">
                <div className="card-header">
                    <h3>Account Details</h3>
                </div>
                <div className="card-body">
                    <h5 className="card-title">Account Holder: {accountDetails.accountHolderName}</h5>
                    <p className="card-text">Account Number: {accountDetails.accountNumber}</p>
                    <p className="card-text">Current Balance: ${balance}</p>
                </div>
            </div>
        </div>
    );
};

export default CurrentBalance;