import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AllAccountDetails = () => {
    const [accounts, setAccounts] = useState([]);

    useEffect(() => {
        fetchAccounts();
    }, []);

    const fetchAccounts = async () => {
        try {
            const response = await axios.get('http://localhost:8081/accounts');
            setAccounts(response.data);
        } catch (error) {
            console.error('Error fetching accounts:', error);
        }
    };

    return (
        <div>
            <h1>All Account Details</h1>
            <table>
                <thead>
                    <tr>
                        <th>Account Number</th>
                        <th>Account Holder Name</th>
                    </tr>
                </thead>
                <tbody>
                    {accounts.map((account) => (
                        <tr key={account.accountNumber}>
                            <td>{account.accountNumber}</td>
                            <td>{account.accountHolderName}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default AllAccountDetails;